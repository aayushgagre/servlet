package com.cg.dao;

import java.util.Map;


import com.cg.bean.Training;

public interface TrainingDao {
	
	public Training updateTraining(Training training);
	
	public Map<Integer, Training> getAll();

}
