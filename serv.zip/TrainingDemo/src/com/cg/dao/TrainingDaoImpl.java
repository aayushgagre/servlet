package com.cg.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;



import com.cg.bean.Training;
import com.cg.util.DBUtil;

public class TrainingDaoImpl implements TrainingDao{

	static Map<Integer,Training> trmap = new HashMap<Integer,Training>();
	Connection con=DBUtil.getConnect();
	Training obj=null;
	@Override
	public Training updateTraining(Training training) {
		// TODO Auto-generated method stub
		
		String qry="select * from Training";
		try{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery(qry);
			
			while(rs.next()){
				int trainingId=rs.getInt(1);
				String trainingName=rs.getString(2);
				int seats=rs.getInt(3);
				
			}
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return null;
	}
	@Override
	public Map<Integer, Training> getAll() {
		// TODO Auto-generated method stub
		return trmap;
	}

}
