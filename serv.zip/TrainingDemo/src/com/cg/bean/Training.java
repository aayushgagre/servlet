package com.cg.bean;

public class Training {

	private int trainingId;
	private String trainingName;
	private int seats;
	public int getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}
	public String getTrainingName() {
		return trainingName;
	}
	public void setTrainingName(String trainingName) {
		this.trainingName = trainingName;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public Training(int trainingId, String trainingName, int seats) {
		super();
		this.trainingId = trainingId;
		this.trainingName = trainingName;
		this.seats = seats;
	}
	@Override
	public String toString() {
		return "Training [trainingId=" + trainingId + ", trainingName="
				+ trainingName + ", seats=" + seats + "]";
	}
	
	
	
}
