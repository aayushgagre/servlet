package com.cg.service;

import com.cg.bean.Training;
import com.cg.dao.TrainingDao;
import com.cg.dao.TrainingDaoImpl;

public class TrainingServiceImpl implements TrainingService{

	TrainingDao dao=new TrainingDaoImpl();
	@Override
	public Training updateTraining(Training training) {
		// TODO Auto-generated method stub
		
		
		
		return dao.updateTraining(training);
	}

}
