package com.cg.service;

import com.cg.bean.Training;

public interface TrainingService {

	public Training updateTraining(Training training);
	
}
